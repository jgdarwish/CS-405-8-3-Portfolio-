// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
// Improved exception handling, logging, and best practices based on instructor feedback.

#include <iostream>
#include <stdexcept>  // Required for standard exceptions
#include <exception>

// ============================================================
// ✅ Custom Exception Class - Derived from std::exception
// ============================================================
class CustomException : public std::exception {
public:
    // Constructor for custom exception with an error message
    explicit CustomException(const std::string& message) : msg_("Custom Exception: " + message) {}

    // Overriding what() method to return exception message
    const char* what() const noexcept override {
        return msg_.c_str();
    }

private:
    std::string msg_; // Holds custom error message
};

// ============================================================
// ✅ Centralized Logging Function - Improves Error Handling
// ============================================================
// Logs errors with function names for better debugging
void logError(const std::string& function, const std::exception& e) {
    std::cerr << "[ERROR] (" << function << ") " << e.what() << std::endl;
}

// ============================================================
// ✅ Function: do_even_more_custom_application_logic
// Purpose: Throws a standard runtime exception
// ============================================================
bool do_even_more_custom_application_logic() {
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    // Throwing a standard runtime exception
    throw std::runtime_error("An error occurred in do_even_more_custom_application_logic");

    return true; // This will never be reached due to exception
}

// ============================================================
// ✅ Function: do_custom_application_logic
// Purpose: Calls another function & wraps it in exception handling
// ============================================================
void do_custom_application_logic() {
    std::cout << "Running Custom Application Logic." << std::endl;

    try {
        // Call function that may throw an exception
        if (do_even_more_custom_application_logic()) {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    } catch (const std::exception& e) {
        // Logs and catches standard exceptions
        logError("do_custom_application_logic", e);
    }

    // Explicitly throwing a custom exception
    throw CustomException("An error occurred in the application logic!");

    std::cout << "Leaving Custom Application Logic." << std::endl;  // Not reached due to exception
}

// ============================================================
// ✅ Function: divide
// Purpose: Performs division and handles divide-by-zero error
// ============================================================
float divide(float num, float den) {
    // ✅ Preemptive validation to prevent divide-by-zero errors
    if (den == 0) {
        throw std::overflow_error("Math Error: Attempted division by zero.");
    }
    return num / den;
}

// ============================================================
// ✅ Function: do_division
// Purpose: Calls divide function with proper exception handling
// ============================================================
void do_division() noexcept {
    float numerator = 10.0f;
    float denominator = 0; // Deliberately set to zero to trigger an error

    try {
        // Attempt division
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    } catch (const std::overflow_error& e) {
        // Logs and handles division-specific errors
        logError("do_division", e);
    }
}

// ============================================================
// ✅ Function: main
// Purpose: Wraps execution in structured exception handling
// ============================================================
int main() {
    std::cout << "Exceptions Tests!" << std::endl;

    try {
        // Calling functions with structured exception handling
        do_division();
        do_custom_application_logic();
    } 
    catch (const CustomException& e) {
        // ✅ Catch and log custom exceptions
        logError("main (Custom Exception)", e);
    } 
    catch (const std::exception& e) {
        // ✅ Catch and log all standard exceptions
        logError("main (Standard Exception)", e);
    } 
    catch (...) {
        // ✅ Catch-all exception handler for unexpected errors
        std::cerr << "[ERROR] Unknown exception occurred!" << std::endl;
    }

    std::cout << "Program execution completed successfully." << std::endl;
    return 0;
}
