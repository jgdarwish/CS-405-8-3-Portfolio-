// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <limits>  // Required for std::numeric_limits
#include <cstring> // Required for std::strlen()

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    // This constant **MUST** remain directly before the user input buffer.
    const std::string account_number = "CharlieBrown42"; 
    
    // Fixed-size character buffer for user input (19 characters + null terminator)
    char user_input[20];

    std::cout << "Enter a value (max 19 characters): ";

    // Read input safely, allowing up to 19 characters + null terminator
    std::cin.getline(user_input, sizeof(user_input));

    // **New Validation:** Ensure actual input length is within limits
    if (std::strlen(user_input) >= sizeof(user_input) - 1) {
        std::cout << "[ERROR] Input exceeded 19 characters! Buffer overflow attempt detected." << std::endl;
        return 1; // Exit to prevent memory corruption
    }

    // Display the user input safely
    std::cout << "You entered: " << user_input << std::endl;

    // Ensure account number remains unchanged
    std::cout << "Account Number = " << account_number << std::endl;

    return 0; // Return 0 indicating successful execution
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu