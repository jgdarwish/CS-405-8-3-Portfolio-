// NumericOverflows.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // typeid

/// <summary>
/// Template function to safely add numbers while detecting overflow.
/// </summary>
/// <typeparam name="T">A numeric type supporting basic math operations</typeparam>
/// <param name="start">The starting number</param>
/// <param name="increment">The amount to add each step</param>
/// <param name="steps">The number of steps</param>
/// <param name="result">Reference variable to store the result</param>
/// <returns>Returns true if addition is successful, false if overflow occurs</returns>
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& result) {
    result = start;

    for (unsigned long int i = 0; i < steps; ++i) {
        // Check for overflow before performing the addition
        if (increment > 0 && result > (std::numeric_limits<T>::max() - increment)) {
            std::cout << "\t[ERROR] Overflow detected!\n";
            return false; // Overflow occurred
        }
        result += increment;
    }
    return true; // No overflow occurred
}

/// <summary>
/// Template function to safely subtract numbers while detecting underflow.
/// </summary>
/// <typeparam name="T">A numeric type supporting basic math operations</typeparam>
/// <param name="start">The starting number</param>
/// <param name="decrement">The amount to subtract each step</param>
/// <param name="steps">The number of steps</param>
/// <param name="result">Reference variable to store the result</param>
/// <returns>Returns true if subtraction is successful, false if underflow occurs</returns>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& result) {
    result = start;

    for (unsigned long int i = 0; i < steps; ++i) {
        // Check for underflow before performing the subtraction
        if (decrement > 0 && result < (std::numeric_limits<T>::min() + decrement)) {
            std::cout << "\t[ERROR] Underflow detected!\n";
            return false; // Underflow occurred
        }
        result -= decrement;
    }
    return true; // No underflow occurred
}

/// <summary>
/// Tests the overflow protection logic in `add_numbers`.
/// </summary>
template <typename T>
void test_overflow() {
    const unsigned long int steps = 5;
    const T increment = std::numeric_limits<T>::max() / steps;
    const T start = 0;
    T result;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    if (add_numbers<T>(start, increment, steps, result)) {
        std::cout << +result << std::endl;
    } else {
        std::cout << "[FAILED] Overflow occurred!\n";
    }

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    if (add_numbers<T>(start, increment, steps + 1, result)) {
        std::cout << +result << std::endl;
    } else {
        std::cout << "[FAILED] Overflow occurred!\n";
    }
}

/// <summary>
/// Tests the underflow protection logic in `subtract_numbers`.
/// </summary>
template <typename T>
void test_underflow() {
    const unsigned long int steps = 5;
    const T decrement = std::numeric_limits<T>::max() / steps;
    const T start = std::numeric_limits<T>::max();
    T result;

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;

    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    if (subtract_numbers<T>(start, decrement, steps, result)) {
        std::cout << +result << std::endl;
    } else {
        std::cout << "[FAILED] Underflow occurred!\n";
    }

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    if (subtract_numbers<T>(start, decrement, steps + 1, result)) {
        std::cout << +result << std::endl;
    } else {
        std::cout << "[FAILED] Underflow occurred!\n";
    }
}

/// <summary>
/// Runs overflow test cases for various data types.
/// </summary>
void do_overflow_tests(const std::string& star_line) {
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_overflow<int>();
    test_overflow<unsigned int>();
    test_overflow<long>();
    test_overflow<unsigned long>();
    test_overflow<float>();
    test_overflow<double>();
}

/// <summary>
/// Runs underflow test cases for various data types.
/// </summary>
void do_underflow_tests(const std::string& star_line) {
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    test_underflow<int>();
    test_underflow<unsigned int>();
    test_underflow<long>();
    test_underflow<unsigned long>();
    test_underflow<float>();
    test_underflow<double>();
}

/// <summary>
/// Entry point into the application
/// </summary>
/// <returns>0 when complete</returns>
int main() {
    const std::string star_line = std::string(50, '*');

    std::cout << "Starting Numeric Underflow / Overflow Tests!" << std::endl;

    // Run the overflow tests
    do_overflow_tests(star_line);

    // Run the underflow tests
    do_underflow_tests(star_line);

    std::cout << std::endl << "All Numeric Underflow / Overflow Tests Complete!" << std::endl;

    return 0;
}